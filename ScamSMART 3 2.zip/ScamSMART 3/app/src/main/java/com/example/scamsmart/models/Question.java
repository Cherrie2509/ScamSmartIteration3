package com.example.scamsmart.models;

public class Question {

    //Model for questions to enable quizzes
    //code changed from this example https://www.geeksforgeeks.org/how-to-create-a-quiz-app-in-android/


    private int ID;
    private String imageurl;
    private String answer;

    public Question(String imageurl, String answer) {
        this.imageurl = imageurl;
        this.answer = answer;
    }

    public Question(int ID, String imageurl, String answer) {
        this.ID = ID;
        this.imageurl = imageurl;
        this.answer = answer;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getImageurl() {
        return imageurl;
    }

    public void setImageurl(String imageurl) {
        this.imageurl = imageurl;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }



}
