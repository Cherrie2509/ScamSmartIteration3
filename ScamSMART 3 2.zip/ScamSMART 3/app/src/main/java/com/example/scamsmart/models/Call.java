package com.example.scamsmart.models;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Call {

    //Matched this model to what the call log returns
    int ID;
    String phNumber;
    String callType;
    String dateString;
    String callDuration;
    String dir;

    public Call(int ID, String phNumber, String callType, String dateString, String callDuration, String dir) {
        this.ID = ID;
        this.phNumber = phNumber;
        this.callType = callType;
        this.dateString = dateString;
        this.callDuration = callDuration;
        this.dir = dir;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getPhNumber() {
        return phNumber;
    }

    public void setPhNumber(String phNumber) {
        this.phNumber = phNumber;
    }

    public String getCallType() {
        return callType;
    }

    public void setCallType(String callType) {
        this.callType = callType;
    }

    public String getDateString() {
        return dateString;
    }

    public void setDateString(String dateString) {
        this.dateString = dateString;
    }

    public String getCallDuration() {
        return callDuration;
    }

    public void setCallDuration(String callDuration) {
        this.callDuration = callDuration;
    }

    public String getDir() {
        return dir;
    }

    public void setDir(String dir) {
        this.dir = dir;
    }
}
