package com.example.scamsmart.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.telecom.TelecomManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.scamsmart.R;

public class block_activity extends AppCompatActivity {

    //Activity which enables user to block numbers via the built in number blocker in android

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_block_activity);

        Button btnViewRecent = findViewById(R.id.btnViewRecent);
        Button btnLaunchBlock = findViewById(R.id.btnLaunchBlock);
        Button btnInstructions = findViewById(R.id.btnInstructions);
        EditText etNumber = findViewById(R.id.etNumber);

        //Check if a number is being passed, if it is, set it ot the edittext
        if(getIntent().hasExtra("Number")){
            String text = getIntent().getExtras().getString("Number");
            etNumber.setText(text);
        }

        //Display the call log with the users recent calls
        btnViewRecent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent startIntent = new Intent(getApplicationContext(), callLog_activity.class);
                startActivity(startIntent);
            }
        });

        //Launch android's built in number blocker
        btnLaunchBlock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String strNumber = String.valueOf(etNumber.getText());
                setClipboard(block_activity.this, strNumber);

                //Launch built in blocker https://developer.android.com/reference/android/telecom/TelecomManager
                TelecomManager telecomManager = (TelecomManager) getSystemService(Context.TELECOM_SERVICE);
                startActivity(telecomManager.createManageBlockedNumbersIntent(), null);

            }
        });

        //Display instructions to the user of how to use the number blocker
        btnInstructions.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent startIntent = new Intent(getApplicationContext(), instruction_activity.class);
                startActivity(startIntent);
            }
        });

    }

    //A method to copy the current number to the user's clipboard
    //adapted from https://stackoverflow.com/questions/19253786/how-to-copy-text-to-clip-board-in-android
    private void setClipboard(Context context, String text) {

        android.content.ClipboardManager clipboard = (android.content.ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
        android.content.ClipData clip = android.content.ClipData.newPlainText("Copied Text", text);
        clipboard.setPrimaryClip(clip);

    }
}