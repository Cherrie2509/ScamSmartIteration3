package com.example.scamsmart.ui;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.media.Image;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.scamsmart.R;
import com.example.scamsmart.models.Question;

public class quiz_activity extends AppCompatActivity {


    //code changed from this example https://www.geeksforgeeks.org/how-to-create-a-quiz-app-in-android/


    ImageView imQuestion;
    Button btnTrust;
    Button btnDont;
    Button btnStart;
    TextView tvWelcome;
    TextView tvThanks;
    Button btnBack;
    int questionCounter;
    int correctCounter;


    //Declaring questions to be asked
    public Question[] questionBank = new Question[] {
            new Question("https://i.imgur.com/0zqb3Cq.png", "Don't Trust"),
            new Question("https://i.imgur.com/3KaDlz8.jpg", "Trust")

    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz_activity);

        questionCounter = 0;

        imQuestion = findViewById(R.id.imQuestion);
        btnTrust = findViewById(R.id.btnTrust);
        btnDont = findViewById(R.id.btnDontTrust);
        btnStart = findViewById(R.id.btnStartQuiz);
        tvWelcome = findViewById(R.id.tvWelcome);
        tvThanks = findViewById(R.id.tvThanks);
        btnBack = findViewById(R.id.btnBackToMenu);


        //Setting buttons to be invisible before the quiz is started
        btnTrust.setVisibility(View.INVISIBLE);
        btnDont.setVisibility(View.INVISIBLE);
        tvThanks.setVisibility(View.INVISIBLE);
        btnBack.setVisibility(View.INVISIBLE);


        //The two answer options
        btnTrust.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkQuestions("Trust");
            }
        });

        btnDont.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkQuestions("Don't Trust");
            }
        });



    btnStart.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            startQuiz();
        }
    });

    btnBack.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent intent = new Intent(quiz_activity.this, MainActivity.class);
            startActivity(intent);

        }
    });



    }

    //Checks if the answer submitted is corrected, and displays the next question, and displays results at the end
    public void checkQuestions(String string) {
        if(string.equals(questionBank[questionCounter].getAnswer())  ) {
            correctCounter +=1;

            if(questionCounter < 1) {
                questionCounter += 1;
                Glide.with(this).load(questionBank[questionCounter].getImageurl()).into(imQuestion);
            }
            else {
                btnTrust.setVisibility(View.INVISIBLE);
                btnDont.setVisibility(View.INVISIBLE);
                imQuestion.setVisibility(View.INVISIBLE);
                tvThanks.setText("Thank you, you scored " + correctCounter + " out of " + questionBank.length);
                tvThanks.setVisibility(View.VISIBLE);
                btnBack.setVisibility(View.VISIBLE);
            }
        }
        else {
            if(questionCounter < 1) {
                questionCounter += 1;
                Glide.with(this).load(questionBank[questionCounter].getImageurl()).into(imQuestion);
            }
            else {
                btnTrust.setVisibility(View.INVISIBLE);
                btnDont.setVisibility(View.INVISIBLE);
                imQuestion.setVisibility(View.INVISIBLE);
                tvThanks.setText("Thank you, you scored " + correctCounter + " out of " + questionBank.length);
                tvThanks.setVisibility(View.VISIBLE);
                btnBack.setVisibility(View.VISIBLE);
            }
        }
    }

    //Setting some controls visible once the quiz is started
    public void startQuiz() {
        btnStart.setVisibility(View.INVISIBLE);
        btnTrust.setVisibility(View.VISIBLE);
        btnDont.setVisibility(View.VISIBLE);
        tvWelcome.setVisibility(View.INVISIBLE);
        Glide.with(this).load(questionBank[questionCounter].getImageurl()).into(imQuestion);
    }



    }






