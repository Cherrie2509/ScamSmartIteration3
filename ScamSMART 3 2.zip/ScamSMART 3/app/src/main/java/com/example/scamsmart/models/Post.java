package com.example.scamsmart.models;

public class Post {


    //Model for recent scam posts

    private int postid;
    private String description;
    private String username;
    private String number;


    public Post(int postid, String description, String username, String number) {
        this.postid = postid;
        this.description = description;
        this.username = username;
        this.number = number;
    }

    public Post() {}

    public int getPostid() {
        return postid;
    }

    public void setPostid(int postid) {
        this.postid = postid;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }
}
