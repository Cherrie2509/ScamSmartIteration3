package com.example.scamsmart.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.example.scamsmart.R;
import com.example.scamsmart.models.Post;
import com.example.scamsmart.ui.block_activity;
import com.example.scamsmart.ui.recent_firebase_activity;
import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;

import org.jetbrains.annotations.NotNull;

public class PostAdapter extends FirestoreRecyclerAdapter<Post, PostAdapter.PostHolder> {

    //This is a FireStore Recycler adapter utilising the Firebase UI library
    //Adapted from https://medium.com/quick-code/display-data-from-firebase-firestore-in-android-recyclerview-db39f8c7d6b

    Context context;

    /**
     * Create a new RecyclerView adapter that listens to a Firestore Query.  See {@link
     * FirestoreRecyclerOptions} for configuration options.
     *
     * @param options
     */
    public PostAdapter(@NonNull @NotNull FirestoreRecyclerOptions<Post> options, Context context) {
        super(options);
        this.context = context;
    }

    @Override
    protected void onBindViewHolder(@NonNull @NotNull PostAdapter.PostHolder holder, int position, @NonNull @NotNull Post model) {
        holder.tvUsername.setText(model.getUsername());
        holder.tvNumber.setText(model.getNumber());
        holder.etDescription.setText(model.getDescription());
        holder.btnBlock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //This passes the number to the blocking activity
                Intent intent = new Intent(context, block_activity.class);
                intent.putExtra("Number", model.getNumber());


                context.startActivity(intent);
            }
        });
    }

    @NonNull
    @NotNull
    @Override
    public PostHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.row,parent,false);
        return new PostHolder(v);
    }

    class PostHolder extends RecyclerView.ViewHolder  {
        TextView tvUsername;
        TextView tvNumber;
        Button btnBlock;
        EditText etDescription;
        ConstraintLayout parentLayout;

        public PostHolder(@NonNull @NotNull View itemView) {
            super(itemView);
            tvUsername = itemView.findViewById(R.id.tvUser);
            tvNumber = itemView.findViewById(R.id.tvNumber);
            btnBlock = itemView.findViewById(R.id.btnBlock);
            etDescription = itemView.findViewById(R.id.etDesc);
            parentLayout = itemView.findViewById(R.id.row);
        }
    }

}
