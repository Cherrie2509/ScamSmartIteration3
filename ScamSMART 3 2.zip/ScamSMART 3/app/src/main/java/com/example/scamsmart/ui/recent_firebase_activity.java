package com.example.scamsmart.ui;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.example.scamsmart.R;
import com.example.scamsmart.adapters.PostAdapter;
import com.example.scamsmart.models.Post;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

public class recent_firebase_activity extends AppCompatActivity {


    //Displays the recent scams in a recycler view
    //https://codinginflow.com/tutorials/android/firebaseui-firestorerecycleradapter/part-3-firestorerecycleradapter

    //Declaration of firebase objects
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private CollectionReference postRef = db.collection("Posts");
    private PostAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recent_firebase);

        setupRecyclerview();
    }

    private void setupRecyclerview() {
        //Sort the records retrieved
        Query query = postRef.orderBy("timestamp", Query.Direction.DESCENDING);

        //Declaring the recycler adapter and displaying it -
        FirestoreRecyclerOptions<Post> options = new FirestoreRecyclerOptions.Builder<Post>()
                .setQuery(query, Post.class)
                .build();
        adapter = new PostAdapter(options,this);
        RecyclerView recyclerView = findViewById(R.id.rvFBPosts);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);
    }

    //This code is required in the onStart and onStop to ensure the recycler updates while the activity is active, and then stops updating when its not
    @Override
    protected void onStart() {
        super.onStart();
        adapter.startListening();
    }

    @Override
    protected void onStop() {
        super.onStop();
        adapter.stopListening();
    }
}