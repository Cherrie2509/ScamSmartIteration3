package com.example.scamsmart.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.example.scamsmart.R;
import com.example.scamsmart.models.Call;

import java.util.List;

public class CallRecyclerAdapter  extends RecyclerView.Adapter<CallRecyclerAdapter.MyViewHolder> {

    //Adapted From this video https://www.youtube.com/watch?v=FFCpjZkqfb0
    //Adapter to display the call log

    List<Call> callList;
    Context context;

    public CallRecyclerAdapter(List<Call> callList, Context context) {
        this.callList = callList;
        this.context = context;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView tvDate;
        TextView tvNumber;

        TextView tvDuration;
        TextView tvType;
        Button btnBlock;


        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            tvDate = itemView.findViewById(R.id.tvDate);
            //tvDuration = itemView.findViewById(R.id.tvDuration);
            tvNumber = itemView.findViewById(R.id.tvNumber);
           // tvType = itemView.findViewById(R.id.tvType);


        }
    }



    @NonNull
    @Override
    public CallRecyclerAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.onecall,parent,false);
        CallRecyclerAdapter.MyViewHolder holder = new CallRecyclerAdapter.MyViewHolder(view);

        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull CallRecyclerAdapter.MyViewHolder holder, int position) {

       // holder.tvDuration.setText(callList.get(position).getCallDuration());
        holder.tvNumber.setText(callList.get(position).getPhNumber());
        holder.tvDate.setText(callList.get(position).getDateString());
        //holder.tvType.setText(callList.get(position).getCallType());



    }


    @Override
    public int getItemCount() {
        return callList.size();

    }








}
